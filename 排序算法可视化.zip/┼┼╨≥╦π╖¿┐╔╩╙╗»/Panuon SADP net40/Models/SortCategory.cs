﻿
namespace Panuon_SADP_net40
{
    /// <summary>
    /// 排序类型（7种）
    /// </summary>
   public enum SortCategory
    {
        InsertSort = 0,
        SelectSort = 1,
        BubbleSort =2,
        MergeSort = 3,
        ShellSort = 4,
        QucikSort = 5,
        BucketSort = 6
    }

}
